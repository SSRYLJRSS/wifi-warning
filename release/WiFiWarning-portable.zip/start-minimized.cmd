@echo off
setlocal
cd /d "%~dp0"
start "" wifi-warning.exe --minimized
