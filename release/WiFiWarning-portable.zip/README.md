# WiFi 提醒

Windows 本地 WiFi 场景提醒工具。主程序在系统托盘运行，提供本地 HTTP 设置页；被替换的快捷方式会先进入 `ww-launch.exe`，由启动器按当前 WiFi 和规则决定拦截或放行。

## 当前实现

- 使用 Windows `WlanApi` 获取当前连接 SSID、扫描可用网络并请求连接。
- WiFi 切换优先使用已保存配置文件；安全网络配置了密码时会先写入 WLAN 配置文件再连接，连接请求会短暂等待当前 SSID 变为目标网络后才标记为已连接，未确认连接但 Windows 已接受请求时返回 `connect_requested`；连接失败时会打开 Windows 网络选择面板，便于输入密码。
- 使用 `%APPDATA%\WiFiWarning\config.json` 持久化配置，损坏配置会备份后重置。
- 使用 JSON Lines 写入 `%APPDATA%\WiFiWarning\logs\YYYY-MM-DD.jsonl`，自动轮转 30 天。
- 提供规则引擎、临时密码绕过、统计读取、开机启动注册表开关。
- 扫描桌面、开始菜单、ProgramData 开始菜单和任务栏固定快捷方式，支持 `.lnk` 备份、替换、还原。
- 主服务提供 `/settings`、`/warning`、`/wifi-picker` 和 REST API。
- 托盘菜单显示当前网络、防护开关、设置、统计和退出。
- `ww-launch.exe` 按 `--app` 与 `--rule` 参数读取配置并执行拦截决策。

## 构建

首选 CMake：

```powershell
cmake -S . -B build
cmake --build build --config Release
```

当前机器没有 `cmake.exe`，仓库也提供了 MinGW 直编脚本：

```powershell
.\scripts\build-mingw.ps1
```

输出在 `build\mingw\bin\`。

打包 portable zip：

```powershell
.\scripts\package-portable.ps1
```

输出在 `build\dist\WiFiWarning-portable.zip`，包内包含：

- `wifi-warning.exe`：主程序，双击即可打开设置页并在托盘后台运行。
- `ww-launch.exe`：被快捷方式调用的启动器。
- `restore-shortcuts.cmd`：仅还原已记录的快捷方式。
- `start-minimized.cmd`：从当前目录启动托盘程序。
- `ww-smoke.exe` 与 `scripts\`：免安装包自检工具。
- `docs\optimization-report.md`：稳定性与占用优化报告。

portable 包不包含安装脚本、NSIS 模板或安装器构建入口。

## 验证

```powershell
.\build\mingw\bin\ww-smoke.exe
```

当前 smoke 覆盖：

- 配置默认值、保存、读取与 JSON round-trip。
- 规则引擎对 SSID + 应用路径的阻止/放行判断。
- JSON Lines 日志写入与统计汇总。
- 临时 `.lnk` 的 ShellLink 创建、替换、读取和还原，并验证原快捷方式参数、图标路径与图标索引会被保留。
- 使用 `WW_SHORTCUT_ROOTS` 指向临时 Desktop/Start Menu/TaskBar 目录，验证真实 `.lnk` 扫描、`/api/shortcuts/scan`、`/api/shortcuts/replace` 和关闭防护后的还原。
- 设置页提供“浏览应用”、扫描快捷方式预览，替换后显示每个应用的快捷方式处理结果。
- 嵌入式 HTTP 服务的 `/api/config` 与 `/settings` 本地访问。
- 嵌入式 HTTP 服务的 `/api/wifi/current`、`/api/wifi/available`、`/api/wifi/switch` 端点；测试中使用 `WW_TEST_CURRENT_SSID`、`WW_TEST_AVAILABLE_WIFI_JSON`、`WW_TEST_CONNECT_WIFI` 避免改变真实网络，并覆盖已连接与 Windows 原生网络面板回退两种结果。
- `/warning` 与 `/wifi-picker` 页面路由。
- `ww-launch.exe` dry-run 的阻止、允许、关闭防护、临时放行决策。
- `ww-launch.exe --no-launch` 阻止路径的 JSONL 日志写入。
- 开机启动注册表助手和 `/api/config` 设置保存路径会在隔离的 HKCU 测试键中写入、检测并移除 `WiFiWarning` 启动项，不触碰真实 Run 键。
- `wifi-warning.exe --uninstall-restore` 会关闭防护和配置中的开机启动。
- `ww-launch.exe` dry-run 阻止路径耗时，当前 smoke 会要求低于 200ms。

运行主程序的本地 HTTP/内存 smoke：

```powershell
.\scripts\runtime-smoke.ps1
```

该脚本使用 `build\runtime\AppData` 作为临时 `%APPDATA%`，启动 `wifi-warning.exe --self-test-server`，访问本地 API，并采样进程工作集内存。

当前 self-test 实测工作集约 3.96 MiB，满足目标中的 `< 5MB RAM idle` 验收线。

校验 CMake 工程文件覆盖当前源码与打包入口：

```powershell
.\scripts\validate-cmake.ps1
```

运行本地验收套件：

```powershell
.\scripts\local-acceptance.ps1
```

该脚本会刷新 MinGW 构建、运行 `ww-smoke.exe`、runtime/tray/browser smoke、CMake 元数据校验、PowerShell/JavaScript 解析检查，并重新生成 portable zip，最后输出包含每一步结果和产物大小的 JSON。它覆盖本机可自动验证的内容；真实 WiFi、NSIS 与 CMake 工具链仍由外部验收预检跟踪。

运行浏览器 UI smoke：

```powershell
.\scripts\browser-smoke.ps1
```

该脚本会启动真实本地 HTTP 服务，使用 Microsoft Edge/Playwright 打开 `/settings`、`/warning` 和 `/wifi-picker`，检查页面文本、资源加载、开机启动设置切换、设置页软件组和三步规则新增 / 编辑 / 删除 / 丢失应用清理、密码与本次启动放行保存、统计页可见日志、警告页切换安全 WiFi / 打开 WiFi 选择器 / 临时允许 / 关闭按钮 / WiFi 变化自动关闭、WiFi 选择页连接按钮、控制尺寸、桌面与移动端横向溢出，并把截图写入 `build\browser-smoke\screenshots`。

运行托盘初始化 smoke：

```powershell
.\scripts\tray-smoke.ps1
```

该脚本会启动真实托盘代码路径、创建隐藏消息窗口、轮询测试 WiFi SSID，触发“防护”菜单命令，验证已记录快捷方式还原与防护关闭，然后自动退出。普通桌面会话实测结果为 `tray:window:icon:adapter` 与 `tray:window:icon:no-adapter`，说明系统通知区域图标、消息窗口、事件循环、菜单命令和无网卡自动关闭防护路径均已验证。

如需验证默认扫描器对真实 Windows 桌面和开始菜单目录的覆盖，可运行：

```powershell
.\scripts\real-shortcut-scan-smoke.ps1
```

该脚本会创建 `WiFiWarningSmoke-*.lnk` 临时快捷方式，扫描后自动删除。普通桌面会话实测已覆盖重定向到 OneDrive 的桌面目录、当前用户开始菜单目录与任务栏固定快捷方式目录。

运行外部验收预检：

```powershell
.\scripts\external-acceptance.ps1
```

该脚本会用 JSON 汇总需要真实机器环境的验收项。默认模式只做预检，不会切换 WiFi、写真实快捷方式或生成安装器；本机当前结果为 `ok: true`，其中 WLAN 接口查询为 `pass`，WLAN 扫描、NSIS 与 CMake 标记为 `missing`，NSIS 安装器构建和真实 WiFi 切换标记为 `skipped`。带 `-RunRealShortcutScan` 的实测结果已通过。

需要做真实验收时可按需添加参数：

```powershell
.\scripts\external-acceptance.ps1 -RunRealShortcutScan
.\scripts\external-acceptance.ps1 -RunRealTraySmoke
.\scripts\external-acceptance.ps1 -RunRealAutoStartSmoke
.\scripts\external-acceptance.ps1 -RunInstallerBuild -MakeNsis "C:\Program Files (x86)\NSIS\makensis.exe"
.\scripts\external-acceptance.ps1 -RunWifiSwitch -SafeWifiSsid "Home-WiFi" -SafeWifiPassword "password-if-needed"
```

真实 WiFi 查询/切换通常需要管理员 PowerShell、Windows 位置权限、可用无线网卡和明确的目标网络。

## 运行

```powershell
.\build\mingw\bin\wifi-warning.exe
```

主程序默认打开：

```text
http://localhost:18765/settings
```

启动器快捷方式目标示例：

```text
ww-launch.exe --app "C:\Program Files\App\App.exe" --rule "rule_001"
```

开发验证模式：

```powershell
.\build\mingw\bin\ww-launch.exe --dry-run --config "C:\path\config.json" --ssid "Office-WiFi" --app "C:\Program Files\App\App.exe" --rule "rule_001"
```

该模式只输出 JSON 决策，不打开浏览器，也不启动目标应用。

## 绿色免安装使用

解压 portable zip 后双击 `wifi-warning.exe`，或运行：

```powershell
.\wifi-warning.exe
```

如需后台启动，运行 `start-minimized.cmd`。删除整个文件夹前，建议先运行 `restore-shortcuts.cmd`，它会调用应用自身的 `--uninstall-restore` 尝试还原已记录的快捷方式并关闭防护。

## 维护命令

```powershell
.\build\mingw\bin\wifi-warning.exe --status
.\build\mingw\bin\wifi-warning.exe --restore-shortcuts
.\build\mingw\bin\wifi-warning.exe --uninstall-restore
```

`--restore-shortcuts` 和 `--uninstall-restore` 会尝试还原所有已记录的快捷方式，并关闭防护。

## API

- `GET /api/config`
- `POST /api/config`
- `GET /api/wifi/current`
- `GET /api/wifi/available`
- `POST /api/wifi/switch`
- `GET /api/stats`
- `POST /api/bypass`
- `POST /api/apps/browse`
- `GET /api/apps/icon?path=...`
- `GET /api/apps/status`
- `POST /api/apps/cleanup`
- `POST /api/shortcuts/scan`
- `POST /api/shortcuts/replace`
- `POST /api/shortcuts/restore`

## 仍需补齐

- 已提供 per-user portable 安装/卸载脚本和 NSIS 图形安装器脚本；当前机器未安装 `makensis.exe`，所以安装器 EXE 尚未在本机生成。
- 真实 Windows WiFi 切换和密码输入仍需在有无线网卡、目标网络、管理员权限与位置权限的机器上验收；当前已提供 Windows 原生网络面板回退，并用测试钩子覆盖已连接、已请求连接、密码连接和系统面板回退路径。
- 可见系统通知区域图标已在普通桌面会话中验收通过；真实系统目录快捷方式扫描已覆盖重定向 OneDrive 桌面、当前用户开始菜单与任务栏固定快捷方式目录；真实 HKCU Run 开机启动写入/移除已用可恢复方式验收通过。浏览器 UI smoke 已覆盖设置页、警告页与 WiFi 选择页的桌面/移动端渲染。
