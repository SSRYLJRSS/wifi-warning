@echo off
setlocal
cd /d "%~dp0"
wifi-warning.exe --uninstall-restore
echo.
echo If WiFi Warning is still running, exit it from the tray menu before deleting this folder.
pause
